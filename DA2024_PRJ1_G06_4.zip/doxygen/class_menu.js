var class_menu =
[
    [ "Menu", "class_menu.html#ad466dd83355124a6ed958430450bfe94", null ],
    [ "basicMaxFlowAll", "class_menu.html#a8d71fd6058789641045c5867fbd33417", null ],
    [ "basicMaxFlowMenu", "class_menu.html#af57d2e0360eeb89f6be08526cab3f8f5", null ],
    [ "basicMaxFlowSingle", "class_menu.html#a73ce04c7d37e28b8c128b7cd82de4cc6", null ],
    [ "basicServiceMenu", "class_menu.html#ae2f61f906d8dd4711ae1ac34f1f2a3e1", null ],
    [ "basicWaterDemand", "class_menu.html#ae521f94c77cb0efdb611a9eebb6ead6e", null ],
    [ "failuresRemovePipe", "class_menu.html#a86f2560eb3997fcaf30270c4ea35c32f", null ],
    [ "failuresRemoveReservoir", "class_menu.html#a3218472424533e628b9f6e51d94110e7", null ],
    [ "failuresRemoveStation", "class_menu.html#a126c390b33f5148a185aef39aa1e76c9", null ],
    [ "lineFailuresMenu", "class_menu.html#a40283fd5e421902c881ec61ba08a8f6c", null ],
    [ "mainMenu", "class_menu.html#a58127793dea8ce30bfaf2ee7c80f1dd1", null ],
    [ "receiveNode", "class_menu.html#a5e8615fc795dc1a6d02e715d16c4581d", null ],
    [ "receiveNode", "class_menu.html#a6ead264d6f46b0a600ce12287af66769", null ],
    [ "setUpCustom", "class_menu.html#af913806c346ef75ea5aa56b036029f2f", null ],
    [ "setUpMenu", "class_menu.html#a8737bc9e47bc898aa243d76d6c065ec6", null ]
];