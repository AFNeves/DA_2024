var hierarchy =
[
    [ "Menu", "class_menu.html", null ],
    [ "Network", "class_network.html", null ],
    [ "Node", "class_node.html", [
      [ "City", "class_city.html", null ],
      [ "Reservoir", "class_reservoir.html", null ],
      [ "Station", "class_station.html", null ]
    ] ],
    [ "Pipe", "class_pipe.html", null ]
];