var class_reservoir =
[
    [ "Reservoir", "class_reservoir.html#a6a52910a69836c5667ed689c5efb5a50", null ],
    [ "getMaxDelivery", "class_reservoir.html#a59a17dd56e7ed41778007f0b5e64e69d", null ],
    [ "getMunicipality", "class_reservoir.html#a05b3ae3fe93212c1e5608cd5aeee1231", null ],
    [ "getName", "class_reservoir.html#aa73308e734ce198e2217ce00205763ba", null ],
    [ "setMaxDelivery", "class_reservoir.html#a16abba15c3f29ac0af1676f53cc9710f", null ],
    [ "setMunicipality", "class_reservoir.html#a6261b63efcbd820ca428ac8eb46124a5", null ],
    [ "setName", "class_reservoir.html#ac0bed821b668e9e83042aae18783c9bf", null ]
];