var class_city =
[
    [ "City", "class_city.html#a8f8794d4d6ead1d784cfdd287e622620", null ],
    [ "getDemand", "class_city.html#afe09db984da8278e771a727e6f586444", null ],
    [ "getName", "class_city.html#a79ba022573d8174291b5dac268ee5ec0", null ],
    [ "getPopulation", "class_city.html#ab4ae07b2a63f1f014b56aae02a15b92d", null ],
    [ "setDemand", "class_city.html#ab2e7337ac5a69af54aa4eab3ba5d7633", null ],
    [ "setName", "class_city.html#a4d5134783296c403aa0335d47b63b4ab", null ],
    [ "setPopulation", "class_city.html#a3516018e17c1909248d83794e30aae64", null ]
];