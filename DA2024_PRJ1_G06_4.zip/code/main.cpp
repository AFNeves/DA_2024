#include "Menu.h"

int main()
{
    Menu menu;
    return 0;
}
